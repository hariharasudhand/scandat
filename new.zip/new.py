class Window2(QMainWindow):
    def __init__(self):
        super().__init__()
        self.string_bundle = StringBundle.get_bundle()
        get_str = lambda str_id: self.string_bundle.get_string(str_id)
        self.setWindowTitle("Scandat Studio")
        self.setGeometry(20, 30, 1300, 800)
        self.setWindowIcon(QIcon('logo5.png'))

        button = QPushButton('Run', self)
        button.setToolTip('This is an example button')
        button.setGeometry(500, 600, 100, 30)
        button.clicked.connect(self.on_click)
        button.clicked.connect(self.on_click)

        button2 = QPushButton('Open Dir', self)
        button2.setToolTip('this is for open directory')
        button2.setGeometry(150, 100, 170, 30)
        button2.clicked.connect(self.dialog)

        button3 = QPushButton('Select Bounding Template', self)
        button3.setToolTip('this is for open directory')
        button3.setGeometry(800, 100, 170, 30)
        button3.clicked.connect(self.on_click)

        button4 = QPushButton('View Results', self)
        button4.setToolTip('this is for open directory')
        button4.setGeometry(1000, 660, 100, 30)
        button4.clicked.connect(self.on_click)

        combobox = QComboBox(self)
        combobox.setToolTip('this is for selection')
        combobox.setGeometry(800, 150, 170, 30)
        pro_list = ['temp1', 'temp2', 'temp3', 'temp4', 'temp5']
        combobox.setEditable(False)
        combobox.addItems(pro_list)
        combobox.activated.connect(self.pro_click)

        self.label_1 = QLabel("", self)
        self.label_1.move(80, 190)
        self.label_1.setStyleSheet("border :1px solid black;")
        self.label_1.resize(370, 400)

        self.label_2 = QLabel("", self)
        self.label_2.move(700, 190)
        self.label_2.setStyleSheet("border :1px solid black;")
        self.label_2.resize(370, 400)

        self.label_4 = QLabel('Run Status :', self)
        self.label_4.move(360, 665)
        self.label_4.setFont(QFont('Arial', 10))

        self.label_7 = QLabel('', self)
        self.label_7.move(440, 665)
        self.label_7.setStyleSheet('border: 1px solid black')
        self.label_7.setFont(QFont('Arial', 10))



        self.show()



    @pyqtSlot()
    def on_click(self):
        print('PyQt5 button click')

    def pro_click(self):
        print('choosen')

    def dialog(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "open the Image file", r"<Default dir>",
                                                   "Image files(*.jpg *.png *.jpeg *.gif)")
        self.label_1.setPixmap(QPixmap(file_name))

    def open_dir(self):
        my_dir = QtGui.QFileDialog.getExistingDirectory(
            self,
            "Open a folder",
            expanduser("~"),
            QtGui.QFileDialog.ShowDirsOnly
        )

    def open_dir_dialog(self, _value=False, dir_path=None, silent=False):
        if not self.may_continue():
            return

        default_open_dir_path = dir_path if dir_path else '.'
        if self.last_open_dir and os.path.exists(self.last_open_dir):
            default_open_dir_path = self.last_open_dir
        else:
            default_open_dir_path = os.path.dirname(self.file_path) if self.file_path else '.'
        if silent != True:
            target_dir_path = ustr(QFileDialog.getExistingDirectory(self,
                                                                    '%s - Open Directory' % __appname__,
                                                                    default_open_dir_path,
                                                                    QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks))
        else:
            target_dir_path = ustr(default_open_dir_path)
        self.last_open_dir = target_dir_path
        self.import_dir_images(target_dir_path)